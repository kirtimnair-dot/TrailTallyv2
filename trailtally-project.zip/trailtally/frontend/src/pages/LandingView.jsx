import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createTrip } from "../api/client";

export default function LandingView() {
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);
    setError("");
    try {
      const { data } = await createTrip(name.trim());
      // data = { id, name, adminToken }
      navigate(`/organizer/${data.id}/${data.adminToken}`);
    } catch (err) {
      setError(
        err.code === "ERR_NETWORK"
          ? "Can't reach the backend. Is it running on http://localhost:4000?"
          : "Something went wrong creating the trip."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="wrap">
      <h1>TrailTally</h1>
      <p className="muted">No login. Create a trip, get a link, share it.</p>

      <form onSubmit={submit} className="card">
        <div className="form-row">
          <input
            type="text"
            placeholder="Trip name (e.g. Goa Weekend)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ flex: 1 }}
          />
        </div>
        <button type="submit" className="primary" disabled={loading}>
          {loading ? "Creating…" : "Create trip"}
        </button>
        {error && <div className="error-box">{error}</div>}
      </form>
    </div>
  );
}
