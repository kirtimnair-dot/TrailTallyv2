import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:4000" });

// ---- Trip lifecycle ----
export const createTrip = (name) => api.post("/trips", { name });
export const getTrip = (tripId, adminToken) =>
  api.get(`/trips/${tripId}?admin=${adminToken}`);

// ---- Participants ----
export const addParticipant = (tripId, adminToken, name) =>
  api.post(`/trips/${tripId}/participants?admin=${adminToken}`, { name });

export const removeParticipant = (tripId, adminToken, participantId) =>
  api.delete(`/trips/${tripId}/participants/${participantId}?admin=${adminToken}`);

// ---- Bookings ----
// booking = { name, vendor, cost, participantIds, paidBy, splitRule, customShares }
export const addBooking = (tripId, adminToken, booking) =>
  api.post(`/trips/${tripId}/bookings?admin=${adminToken}`, booking);

export const editBooking = (tripId, adminToken, bookingId, patch) =>
  api.patch(`/trips/${tripId}/bookings/${bookingId}?admin=${adminToken}`, patch);

export const deleteBooking = (tripId, adminToken, bookingId) =>
  api.delete(`/trips/${tripId}/bookings/${bookingId}?admin=${adminToken}`);

// ---- Personal link (no auth needed — token IS the auth) ----
export const getMyTrip = (token) => api.get(`/me/${token}`);

// ---- AI layer ----
export const getFairness = (tripId, adminToken) =>
  api.get(`/trips/${tripId}/fairness?admin=${adminToken}`);

export const settleTrip = (tripId, adminToken) =>
  api.post(`/trips/${tripId}/settle?admin=${adminToken}`);

export default api;
