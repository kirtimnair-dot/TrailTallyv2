import { BrowserRouter, Routes, Route } from "react-router-dom";
import LandingView from "./pages/LandingView";
import OrganizerView from "./components/OrganizerView";
import ParticipantView from "./components/ParticipantView";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingView />} />
        <Route path="/organizer/:tripId/:adminToken" element={<OrganizerView />} />
        <Route path="/me/:token" element={<ParticipantView />} />
        <Route
          path="*"
          element={
            <div className="wrap">
              <h1>No trip here</h1>
              <p>Ask your organizer for a link, or go back and create a trip.</p>
            </div>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
