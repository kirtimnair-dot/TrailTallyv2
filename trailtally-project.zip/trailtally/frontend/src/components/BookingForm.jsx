import { useState } from "react";

export default function BookingForm({ participants, onAdd, disabled }) {
  const [name, setName] = useState("");
  const [vendor, setVendor] = useState("");
  const [cost, setCost] = useState("");
  const [paidBy, setPaidBy] = useState("");
  const [selected, setSelected] = useState([]);

  const toggleParticipant = (id) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim() || !cost || selected.length === 0) return;
    onAdd({
      name: name.trim(),
      vendor: vendor.trim(),
      cost: Number(cost),
      participantIds: selected,
      paidBy: paidBy || null,
      splitRule: "equal",
    });
    setName("");
    setVendor("");
    setCost("");
    setPaidBy("");
    setSelected([]);
  };

  return (
    <form onSubmit={submit} className="card">
      <div className="form-row">
        <input
          type="text"
          placeholder="Booking name (e.g. Boat Trip)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Vendor (optional)"
          value={vendor}
          onChange={(e) => setVendor(e.target.value)}
        />
      </div>
      <div className="form-row">
        <input
          type="number"
          placeholder="Cost"
          value={cost}
          onChange={(e) => setCost(e.target.value)}
        />
        <select value={paidBy} onChange={(e) => setPaidBy(e.target.value)}>
          <option value="">Paid by…</option>
          {participants.map((p) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      </div>

      <p className="muted" style={{ margin: "8px 0 4px" }}>Split between:</p>
      <div className="checkbox-row">
        {participants.map((p) => (
          <label key={p.id}>
            <input
              type="checkbox"
              checked={selected.includes(p.id)}
              onChange={() => toggleParticipant(p.id)}
            />
            {p.name}
          </label>
        ))}
      </div>

      <button type="submit" className="primary" disabled={disabled} style={{ marginTop: 10 }}>
        Add booking
      </button>
    </form>
  );
}
