import { useState } from "react";

export default function ParticipantForm({ onAdd, disabled }) {
  const [name, setName] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd(name.trim());
    setName("");
  };

  return (
    <form className="form-row" onSubmit={submit}>
      <input
        type="text"
        placeholder="Participant name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button type="submit" disabled={disabled}>Add participant</button>
    </form>
  );
}
