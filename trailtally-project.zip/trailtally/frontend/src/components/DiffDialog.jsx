export default function DiffDialog({ changes, onClose }) {
  return (
    <div className="dialog">
      <div className="dialog-box">
        <h3>Here's what changed</h3>
        {changes.length === 0 ? (
          <p className="muted">No balances were affected.</p>
        ) : (
          <ul>
            {changes.map((c) => (
              <li key={c.participantId}>{c.message}</li>
            ))}
          </ul>
        )}
        <button className="primary" onClick={onClose}>Got it</button>
      </div>
    </div>
  );
}
