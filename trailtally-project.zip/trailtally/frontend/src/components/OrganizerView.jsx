import { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import {
  getTrip,
  addParticipant,
  removeParticipant,
  addBooking,
  getFairness,
} from "../api/client";
import BalancesTable from "./BalancesTable";
import ParticipantForm from "./ParticipantForm";
import BookingForm from "./BookingForm";
import ShareButton from "./ShareButton";
import DiffDialog from "./DiffDialog";

export default function OrganizerView() {
  const { tripId, adminToken } = useParams();
  const [trip, setTrip] = useState(null);
  const [fairness, setFairness] = useState(null);
  const [pendingDiff, setPendingDiff] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const { data } = await getTrip(tripId, adminToken);
      setTrip(data);
      setError("");
    } catch (err) {
      setError(
        err.response?.status === 403
          ? "Invalid admin link."
          : err.response?.status === 404
          ? "Trip not found."
          : "Can't reach the backend. Is it running on http://localhost:4000?"
      );
    } finally {
      setLoading(false);
    }
  }, [tripId, adminToken]);

  const loadFairness = useCallback(async () => {
    try {
      const { data } = await getFairness(tripId, adminToken);
      setFairness(data);
    } catch {
      // non-critical, ignore
    }
  }, [tripId, adminToken]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (trip) loadFairness();
  }, [trip?.bookings?.length, trip?.participants?.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleAddParticipant = async (name) => {
    setBusy(true);
    try {
      await addParticipant(tripId, adminToken, name);
      await load();
    } catch {
      setError("Couldn't add participant.");
    } finally {
      setBusy(false);
    }
  };

  const handleRemoveParticipant = async (participantId) => {
    setBusy(true);
    try {
      const { data } = await removeParticipant(tripId, adminToken, participantId);
      setPendingDiff(data.changes);
      setTrip(data.trip);
    } catch {
      setError("Couldn't remove participant.");
    } finally {
      setBusy(false);
    }
  };

  const handleAddBooking = async (booking) => {
    setBusy(true);
    try {
      const { data } = await addBooking(tripId, adminToken, booking);
      setTrip(data.trip);
    } catch {
      setError("Couldn't add booking.");
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="wrap">Loading trip…</div>;
  if (error && !trip) return <div className="wrap"><div className="error-box">{error}</div></div>;
  if (!trip) return null;

  const flaggedIds = new Set((fairness?.flagged || []).map((f) => f.participantId));

  return (
    <div className="wrap">
      <h1>{trip.name}</h1>
      <p className="muted">Organizer link — keep this private. Trip ID: {trip.id}</p>
      {error && <div className="error-box">{error}</div>}

      <h2>Participants</h2>
      {trip.participants.map((p) => (
        <div key={p.id} className="row">
          <span>
            {p.name} —{" "}
            <span className={(trip.net[p.id] ?? 0) >= 0 ? "balance-positive" : "balance-negative"}>
              ₹{Math.abs(trip.net[p.id] ?? 0)} {(trip.net[p.id] ?? 0) >= 0 ? "owed" : "owes"}
            </span>
            {flaggedIds.has(p.id) && <span className="badge">⚠ fairness flag</span>}
          </span>
          <span>
            <ShareButton tripName={trip.name} token={p.token} />{" "}
            <button className="danger" disabled={busy} onClick={() => handleRemoveParticipant(p.id)}>
              Remove
            </button>
          </span>
        </div>
      ))}
      <ParticipantForm onAdd={handleAddParticipant} disabled={busy} />

      <h2>Bookings</h2>
      <BalancesTable
        bookings={trip.bookings}
        participants={trip.participants}
        shares={trip.shares}
        paid={trip.paid}
        net={trip.net}
      />
      <BookingForm participants={trip.participants} onAdd={handleAddBooking} disabled={busy} />

      {pendingDiff && (
        <DiffDialog changes={pendingDiff} onClose={() => setPendingDiff(null)} />
      )}
    </div>
  );
}
