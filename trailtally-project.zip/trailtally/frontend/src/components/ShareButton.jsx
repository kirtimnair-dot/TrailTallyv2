import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";

export default function ShareButton({ tripName, token }) {
  const [showQR, setShowQR] = useState(false);
  const shareLink = `${window.location.origin}/me/${token}`;

  const openWhatsApp = () => {
    const text = `Here's your TrailTally link for ${tripName}: ${shareLink}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <span>
      <button onClick={openWhatsApp}>WhatsApp</button>{" "}
      <button onClick={() => setShowQR((v) => !v)}>QR</button>
      {showQR && (
        <div className="qr-box">
          <QRCodeSVG value={shareLink} size={120} />
        </div>
      )}
    </span>
  );
}
