export default function BalancesTable({ bookings, participants, shares, paid, net }) {
  const nameOf = (id) => participants.find((p) => p.id === id)?.name || id;

  return (
    <>
      <table>
        <thead>
          <tr>
            <th>Booking</th>
            <th>Cost</th>
            <th>Paid by</th>
            <th>Split among</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((b) => (
            <tr key={b.id}>
              <td>{b.name}{b.vendor ? ` (${b.vendor})` : ""}</td>
              <td>₹{b.cost}</td>
              <td>{b.paidBy ? nameOf(b.paidBy) : "—"}</td>
              <td>{b.participantIds.map(nameOf).join(", ") || "—"}</td>
            </tr>
          ))}
          {bookings.length === 0 && (
            <tr><td colSpan={4} className="muted">No bookings yet</td></tr>
          )}
        </tbody>
      </table>

      {shares && (
        <table>
          <thead>
            <tr>
              <th>Participant</th>
              <th>Owes</th>
              <th>Paid</th>
              <th>Net</th>
            </tr>
          </thead>
          <tbody>
            {participants.map((p) => {
              const n = net?.[p.id] ?? 0;
              return (
                <tr key={p.id}>
                  <td>{p.name}</td>
                  <td>₹{shares[p.id] ?? 0}</td>
                  <td>₹{paid?.[p.id] ?? 0}</td>
                  <td className={n >= 0 ? "balance-positive" : "balance-negative"}>
                    {n >= 0 ? `owed ₹${n}` : `owes ₹${Math.abs(n)}`}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </>
  );
}
