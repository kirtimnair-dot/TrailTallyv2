import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getMyTrip } from "../api/client";

export default function ParticipantView() {
  const { token } = useParams();
  const [me, setMe] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyTrip(token)
      .then(({ data }) => setMe(data))
      .catch(() => setError("Link not found. Check the URL your organizer sent."))
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) return <div className="wrap">Loading…</div>;
  if (error) return <div className="wrap"><h1>Oops</h1><p>{error}</p></div>;
  if (!me) return null;

  return (
    <div className="wrap">
      <h1>Hi {me.participant.name}</h1>
      <p className="muted">{me.tripName}</p>

      <div className="card">
        <p>
          You {me.net >= 0 ? "are owed" : "owe"}{" "}
          <span className={me.net >= 0 ? "balance-positive" : "balance-negative"}>
            ₹{Math.abs(me.net)}
          </span>
        </p>
        <p className="muted">Total share: ₹{me.amountOwed} · Paid: ₹{me.amountPaid}</p>
      </div>

      <h2>Your itinerary</h2>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Your share</th>
          </tr>
        </thead>
        <tbody>
          {me.activities.map((a) => (
            <tr key={a.id}>
              <td>{a.name}{a.vendor ? ` (${a.vendor})` : ""}</td>
              <td>₹{a.yourShare}</td>
            </tr>
          ))}
          {me.activities.length === 0 && (
            <tr><td colSpan={2} className="muted">Nothing booked for you yet</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
