/**
 * TrailTally — in-memory store (no DB, matches the 6-hour build plan)
 *
 * Data shapes:
 *   Trip:        { id, name, adminToken, createdAt, participants: Participant[], bookings: Booking[] }
 *   Participant: { id, name, token }                       // token = their personal /me/:token link
 *   Booking:     { id, name, vendor, cost, participantIds: string[], paidBy: string|null, splitRule: 'equal'|'custom', customShares?: {participantId: amount} }
 *
 * The one non-obvious piece: every mutating operation (add/edit/delete booking,
 * remove participant) computes shares BEFORE and AFTER the change and returns a
 * diff — that diff is the app's actual USP, not an afterthought.
 */

const crypto = require('crypto');

const trips = new Map(); // tripId -> Trip

function genId(prefix, len = 8) {
  return `${prefix}_${crypto.randomBytes(len).toString('base64url').slice(0, len)}`;
}

// ---------- Trip / Participant / Booking CRUD -------------------------------

function createTrip(name) {
  const trip = {
    id: genId('trip'),
    name: name || 'Untitled Trip',
    adminToken: genId('admin', 10),
    createdAt: new Date().toISOString(),
    participants: [],
    bookings: [],
  };
  trips.set(trip.id, trip);
  return trip;
}

function getTrip(tripId) {
  return trips.get(tripId) || null;
}

function requireAdmin(trip, adminToken) {
  return !!trip && trip.adminToken === adminToken;
}

function addParticipant(trip, name) {
  const participant = { id: genId('p', 6), name: name || 'Guest', token: genId('me', 10) };
  trip.participants.push(participant);
  return participant;
}

function removeParticipant(trip, participantId) {
  const removed = trip.participants.find((p) => p.id === participantId);
  const before = computeShares(trip);
  trip.participants = trip.participants.filter((p) => p.id !== participantId);
  // Drop the removed participant from every booking they were part of
  trip.bookings.forEach((b) => {
    b.participantIds = b.participantIds.filter((pid) => pid !== participantId);
    if (b.paidBy === participantId) b.paidBy = null;
  });
  const after = computeShares(trip);
  const nameOverrides = removed ? { [removed.id]: removed.name } : {};
  return computeDiff(trip, before, after, nameOverrides);
}

function findParticipantByToken(token) {
  for (const trip of trips.values()) {
    const participant = trip.participants.find((p) => p.token === token);
    if (participant) return { trip, participant };
  }
  return null;
}

function addBooking(trip, input) {
  const booking = {
    id: genId('b', 6),
    name: input.name || 'Untitled booking',
    vendor: input.vendor || '',
    cost: Number(input.cost) || 0,
    participantIds: Array.isArray(input.participantIds) ? input.participantIds : [],
    paidBy: input.paidBy || null,
    splitRule: input.splitRule === 'custom' ? 'custom' : 'equal',
    customShares: input.customShares || {},
  };
  trip.bookings.push(booking);
  return booking;
}

function updateBooking(trip, bookingId, updates) {
  const booking = trip.bookings.find((b) => b.id === bookingId);
  if (!booking) return null;

  const before = computeShares(trip);
  Object.assign(booking, {
    ...('name' in updates ? { name: updates.name } : {}),
    ...('vendor' in updates ? { vendor: updates.vendor } : {}),
    ...('cost' in updates ? { cost: Number(updates.cost) || 0 } : {}),
    ...('participantIds' in updates ? { participantIds: updates.participantIds } : {}),
    ...('paidBy' in updates ? { paidBy: updates.paidBy } : {}),
    ...('splitRule' in updates ? { splitRule: updates.splitRule === 'custom' ? 'custom' : 'equal' } : {}),
    ...('customShares' in updates ? { customShares: updates.customShares } : {}),
  });
  const after = computeShares(trip);
  return { booking, diff: computeDiff(trip, before, after) };
}

function deleteBooking(trip, bookingId) {
  const before = computeShares(trip);
  trip.bookings = trip.bookings.filter((b) => b.id !== bookingId);
  const after = computeShares(trip);
  return computeDiff(trip, before, after);
}

// ---------- Share & diff engine (the actual USP) -----------------------------

/** @returns {Object<string, number>} participantId -> total amount they owe across all bookings */
function computeShares(trip) {
  const shares = {};
  trip.participants.forEach((p) => { shares[p.id] = 0; });

  for (const booking of trip.bookings) {
    const ids = booking.participantIds.filter((pid) => shares[pid] !== undefined);
    if (!ids.length) continue;

    if (booking.splitRule === 'custom') {
      for (const pid of ids) {
        shares[pid] += Number(booking.customShares[pid]) || 0;
      }
    } else {
      const share = booking.cost / ids.length;
      for (const pid of ids) shares[pid] += share;
    }
  }

  for (const pid in shares) shares[pid] = Number(shares[pid].toFixed(2));
  return shares;
}

/** @returns {Object<string, number>} participantId -> total amount they've paid (front-of-money on bookings) */
function computePaid(trip) {
  const paid = {};
  trip.participants.forEach((p) => { paid[p.id] = 0; });
  for (const booking of trip.bookings) {
    if (booking.paidBy && paid[booking.paidBy] !== undefined) {
      paid[booking.paidBy] += booking.cost;
    }
  }
  for (const pid in paid) paid[pid] = Number(paid[pid].toFixed(2));
  return paid;
}

/**
 * Compares two share snapshots and returns only the participants whose share
 * actually changed. `nameOverrides` supplies display names for participants
 * who are no longer in trip.participants by the time this runs (e.g. just removed).
 */
function computeDiff(trip, before, after, nameOverrides = {}) {
  const changes = [];
  const ids = new Set([...Object.keys(before), ...Object.keys(after)]);
  for (const pid of ids) {
    const b = before[pid] ?? 0;
    const a = after[pid] ?? 0;
    const delta = Number((a - b).toFixed(2));
    if (Math.abs(delta) >= 0.01) {
      const participant = trip.participants.find((p) => p.id === pid);
      const name = participant ? participant.name : nameOverrides[pid] || '(removed)';
      changes.push({
        participantId: pid,
        name,
        before: b,
        after: a,
        delta,
        message:
          delta > 0
            ? `${name}'s share goes up by ₹${delta}`
            : `${name} is owed a ₹${Math.abs(delta)} refund`,
      });
    }
  }
  return changes.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
}

module.exports = {
  trips,
  createTrip,
  getTrip,
  requireAdmin,
  addParticipant,
  removeParticipant,
  findParticipantByToken,
  addBooking,
  updateBooking,
  deleteBooking,
  computeShares,
  computePaid,
  computeDiff,
};
