# TrailTally backend

Matches the API sketch from the build-workflow doc. In-memory store, no DB, no
login system — access is entirely via tokens:

- `adminToken` (returned when you create a trip) — organizer access
- each participant's `token` — their personal `/me/:token` link (no signup)

## Run it

```bash
npm install
npm start          # server on http://localhost:4000
```

## Test it

```bash
node run_test.js   # boots the server in-process, runs the full flow, exits
```

This walks through: create trip → add 5 participants → add 2 bookings →
remove a participant (checks a diff comes back) → edit a booking (checks
another diff) → personal `/me/` view → fairness check → settle.

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/trips` | — | Create trip → `{ id, adminToken }` |
| GET | `/trips/:id?admin=` | admin | Full organizer view: participants, bookings, shares, paid, net |
| POST | `/trips/:id/participants?admin=` | admin | Add participant → returns their personal token |
| DELETE | `/trips/:id/participants/:pid?admin=` | admin | Remove participant → returns `{ changes: [...] }` diff |
| POST | `/trips/:id/bookings?admin=` | admin | Add booking (vendor, cost, participantIds, paidBy, splitRule) |
| PATCH | `/trips/:id/bookings/:bid?admin=` | admin | Edit booking → returns `{ booking, changes }` diff |
| DELETE | `/trips/:id/bookings/:bid?admin=` | admin | Cancel booking → returns diff |
| GET | `/me/:token` | token IS the auth | One participant's itinerary + balance only |
| GET | `/trips/:id/fairness?admin=` | admin | Z-score anomaly flags |
| POST | `/trips/:id/settle?admin=` | admin | Debt-simplifier → minimal settlement transactions |

## Booking shape

```json
{
  "name": "Boat Trip",
  "vendor": "SeaTours",
  "cost": 12000,
  "participantIds": ["p_abc", "p_def"],
  "paidBy": "p_abc",
  "splitRule": "equal",       // or "custom"
  "customShares": { "p_abc": 5000, "p_def": 7000 }   // only used if splitRule === "custom"
}
```

## Wiring up the frontend

- Every mutating call (add/edit/delete booking, remove participant) returns a
  `changes` array — render that as the confirm-diff dialog described in the
  workflow doc before the change is considered "seen."
- `GET /trips/:id?admin=` is what the organizer dashboard polls/reloads on.
- `GET /me/:token` is the entire personal-link page — no other calls needed.
- CORS is already open (`cors()` with defaults) so the Vite dev server can hit
  `http://localhost:4000` directly with no proxy config.
