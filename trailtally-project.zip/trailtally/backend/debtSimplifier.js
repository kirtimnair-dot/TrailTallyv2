/**
 * Debt Simplifier — turns "who owes what" into the minimum number of
 * payments needed to settle everyone up.
 *
 * Input: netBalances = { participantId: paidTotal - owedTotal }
 *   positive net  -> they overpaid, they're owed money (creditor)
 *   negative net  -> they underpaid, they owe money (debtor)
 *
 * Greedy approach: repeatedly match the biggest debtor with the biggest
 * creditor. Not provably minimal in every edge case, but produces a small,
 * sensible transaction list in O(n log n) — plenty for a trip-sized group.
 */
function simplifyDebts(netBalances, participantNames = {}) {
  const EPSILON = 0.01;

  const creditors = [];
  const debtors = [];
  for (const [pid, net] of Object.entries(netBalances)) {
    if (net > EPSILON) creditors.push({ pid, amount: net });
    else if (net < -EPSILON) debtors.push({ pid, amount: -net }); // store as positive owed
  }

  creditors.sort((a, b) => b.amount - a.amount);
  debtors.sort((a, b) => b.amount - a.amount);

  const transactions = [];
  let ci = 0, di = 0;

  while (ci < creditors.length && di < debtors.length) {
    const creditor = creditors[ci];
    const debtor = debtors[di];
    const amount = Number(Math.min(creditor.amount, debtor.amount).toFixed(2));

    if (amount > EPSILON) {
      transactions.push({
        from: debtor.pid,
        fromName: participantNames[debtor.pid] || debtor.pid,
        to: creditor.pid,
        toName: participantNames[creditor.pid] || creditor.pid,
        amount,
      });
    }

    creditor.amount = Number((creditor.amount - amount).toFixed(2));
    debtor.amount = Number((debtor.amount - amount).toFixed(2));

    if (creditor.amount <= EPSILON) ci++;
    if (debtor.amount <= EPSILON) di++;
  }

  return transactions;
}

module.exports = { simplifyDebts };
