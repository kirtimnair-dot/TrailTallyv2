/**
 * Fairness Anomaly Detection (z-score) — same logic as the earlier AI-engine
 * module, adapted to take a { participantId: totalOwed } map directly since
 * that's what store.computeShares() already produces.
 */
function fairnessAnomalyDetection(shares, participantNames = {}, zThreshold = 1.5) {
  const totals = Object.values(shares);
  const n = totals.length;
  if (n === 0) return { groupAverage: 0, groupStdDev: 0, flagged: [] };

  const groupAverage = totals.reduce((s, v) => s + v, 0) / n;
  const variance = totals.reduce((s, v) => s + (v - groupAverage) ** 2, 0) / n;
  const groupStdDev = Math.sqrt(variance);

  const flagged = [];
  for (const [participantId, total] of Object.entries(shares)) {
    const zScore = groupStdDev === 0 ? 0 : (total - groupAverage) / groupStdDev;
    if (Math.abs(zScore) >= zThreshold) {
      flagged.push({
        participantId,
        name: participantNames[participantId] || participantId,
        total: Number(total.toFixed(2)),
        zScore: Number(zScore.toFixed(2)),
      });
    }
  }

  return {
    groupAverage: Number(groupAverage.toFixed(2)),
    groupStdDev: Number(groupStdDev.toFixed(2)),
    flagged: flagged.sort((a, b) => Math.abs(b.zScore) - Math.abs(a.zScore)),
  };
}

module.exports = { fairnessAnomalyDetection };
