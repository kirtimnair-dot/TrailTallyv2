/**
 * TrailTally backend — matches the API sketch in the build-workflow doc.
 * In-memory store (no DB setup needed), token-based access (no login):
 *   - adminToken -> organizer access to a trip
 *   - participant.token -> that one participant's personal /me/:token view
 */
const express = require('express');
const cors = require('cors');
const store = require('./store');
const { simplifyDebts } = require('./debtSimplifier');
const { fairnessAnomalyDetection } = require('./fairness');

const app = express();
app.use(cors());
app.use(express.json());

// ---------- helpers -----------------------------------------------------

function participantNameMap(trip) {
  const map = {};
  trip.participants.forEach((p) => { map[p.id] = p.name; });
  return map;
}

function tripSummary(trip) {
  const shares = store.computeShares(trip);
  const paid = store.computePaid(trip);
  const net = {};
  trip.participants.forEach((p) => {
    net[p.id] = Number(((paid[p.id] || 0) - (shares[p.id] || 0)).toFixed(2));
  });
  return {
    id: trip.id,
    name: trip.name,
    participants: trip.participants.map((p) => ({ id: p.id, name: p.name, token: p.token })),
    bookings: trip.bookings,
    shares,
    paid,
    net,
  };
}

function loadTripOr404(req, res) {
  const trip = store.getTrip(req.params.id);
  if (!trip) {
    res.status(404).json({ error: 'Trip not found' });
    return null;
  }
  return trip;
}

function requireAdminOr403(req, res, trip) {
  const adminToken = req.query.admin || req.body.admin;
  if (!store.requireAdmin(trip, adminToken)) {
    res.status(403).json({ error: 'Invalid or missing admin token' });
    return false;
  }
  return true;
}

// ---------- Trip lifecycle -----------------------------------------------

// POST /trips  { name }
app.post('/trips', (req, res) => {
  const trip = store.createTrip(req.body.name);
  res.status(201).json({ id: trip.id, name: trip.name, adminToken: trip.adminToken });
});

// GET /trips/:id?admin=...  -> full organizer view
app.get('/trips/:id', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;
  res.json(tripSummary(trip));
});

// ---------- Participants ---------------------------------------------------

// POST /trips/:id/participants?admin=...  { name }
app.post('/trips/:id/participants', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const participant = store.addParticipant(trip, req.body.name);
  res.status(201).json({ participant, shareLink: `/me/${participant.token}` });
});

// DELETE /trips/:id/participants/:pid?admin=...  -> returns diff
app.delete('/trips/:id/participants/:pid', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const diff = store.removeParticipant(trip, req.params.pid);
  res.json({ changes: diff, trip: tripSummary(trip) });
});

// ---------- Bookings ---------------------------------------------------

// POST /trips/:id/bookings?admin=...  { name, vendor, cost, participantIds, paidBy, splitRule, customShares }
app.post('/trips/:id/bookings', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const booking = store.addBooking(trip, req.body);
  res.status(201).json({ booking, trip: tripSummary(trip) });
});

// PATCH /trips/:id/bookings/:bid?admin=...  -> returns diff
app.patch('/trips/:id/bookings/:bid', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const result = store.updateBooking(trip, req.params.bid, req.body);
  if (!result) return res.status(404).json({ error: 'Booking not found' });
  res.json({ booking: result.booking, changes: result.diff, trip: tripSummary(trip) });
});

// DELETE /trips/:id/bookings/:bid?admin=...  -> returns diff (e.g. cancellation)
app.delete('/trips/:id/bookings/:bid', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const diff = store.deleteBooking(trip, req.params.bid);
  res.json({ changes: diff, trip: tripSummary(trip) });
});

// ---------- Personal link (no login) ------------------------------------

// GET /me/:token  -> that one participant's itinerary + balance, nothing else
app.get('/me/:token', (req, res) => {
  const found = store.findParticipantByToken(req.params.token);
  if (!found) return res.status(404).json({ error: 'Invalid or expired link' });

  const { trip, participant } = found;
  const shares = store.computeShares(trip);
  const paid = store.computePaid(trip);
  const myBookings = trip.bookings.filter((b) => b.participantIds.includes(participant.id));

  res.json({
    tripName: trip.name,
    participant: { id: participant.id, name: participant.name },
    amountOwed: shares[participant.id] || 0,
    amountPaid: paid[participant.id] || 0,
    net: Number(((paid[participant.id] || 0) - (shares[participant.id] || 0)).toFixed(2)),
    activities: myBookings.map((b) => ({
      id: b.id,
      name: b.name,
      vendor: b.vendor,
      yourShare:
        b.splitRule === 'custom'
          ? Number(b.customShares[participant.id]) || 0
          : Number((b.cost / b.participantIds.length).toFixed(2)),
    })),
  });
});

// ---------- AI / intelligence layer -----------------------------------------

// GET /trips/:id/fairness?admin=...
app.get('/trips/:id/fairness', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const shares = store.computeShares(trip);
  const result = fairnessAnomalyDetection(shares, participantNameMap(trip));
  res.json(result);
});

// POST /trips/:id/settle?admin=...  -> minimal settlement transactions
app.post('/trips/:id/settle', (req, res) => {
  const trip = loadTripOr404(req, res);
  if (!trip) return;
  if (!requireAdminOr403(req, res, trip)) return;

  const shares = store.computeShares(trip);
  const paid = store.computePaid(trip);
  const net = {};
  trip.participants.forEach((p) => {
    net[p.id] = Number(((paid[p.id] || 0) - (shares[p.id] || 0)).toFixed(2));
  });

  const transactions = simplifyDebts(net, participantNameMap(trip));
  res.json({ transactions });
});

// ---------- health check -----------------------------------------------

app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`TrailTally backend running on http://localhost:${PORT}`));
}

module.exports = app;
