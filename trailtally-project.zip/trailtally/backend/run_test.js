const app = require('./index');

const PORT = 4001;
const server = app.listen(PORT, async () => {
  const BASE = `http://localhost:${PORT}`;

  async function req(method, path, body) {
    const res = await fetch(`${BASE}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`${method} ${path} -> ${res.status}: ${JSON.stringify(json)}`);
    return json;
  }

  try {
    console.log('1. Create trip');
    const { id: tripId, adminToken } = await req('POST', '/trips', { name: 'Goa Trip' });
    console.log('   trip:', tripId);

    console.log('2. Add participants');
    const names = ['Aria', 'Kabir', 'Zara', 'Rohan', 'Maya'];
    const participants = [];
    for (const name of names) {
      const { participant } = await req('POST', `/trips/${tripId}/participants?admin=${adminToken}`, { name });
      participants.push(participant);
    }
    console.log('   ', participants.map((p) => `${p.name}:${p.id}`).join(', '));

    const [aria, kabir, zara, rohan, maya] = participants;

    console.log('3. Add bookings');
    const boat = await req('POST', `/trips/${tripId}/bookings?admin=${adminToken}`, {
      name: 'Boat Trip', vendor: 'SeaTours', cost: 12000, paidBy: aria.id,
      participantIds: [aria.id, kabir.id, zara.id, rohan.id, maya.id],
    });
    await req('POST', `/trips/${tripId}/bookings?admin=${adminToken}`, {
      name: 'Room 2 (shared)', vendor: 'Hotel Sunset', cost: 6000, paidBy: kabir.id,
      participantIds: [kabir.id, zara.id],
    });
    console.log('   2 bookings added, boat booking id:', boat.booking.id);

    console.log('4. Organizer view (shares)');
    const summary1 = await req('GET', `/trips/${tripId}?admin=${adminToken}`);
    console.log('   shares:', summary1.shares);

    console.log('5. Remove Zara -> expect a diff');
    const removal = await req('DELETE', `/trips/${tripId}/participants/${zara.id}?admin=${adminToken}`);
    console.log('   diff:', removal.changes.map((c) => c.message));
    if (removal.changes.length === 0) throw new Error('Expected a non-empty diff after removing a participant');

    console.log('6. Edit a booking -> expect a diff (drop Rohan from the boat trip)');
    const editResult = await req('PATCH', `/trips/${tripId}/bookings/${boat.booking.id}?admin=${adminToken}`, {
      participantIds: [aria.id, kabir.id, maya.id],
    });
    console.log('   diff:', editResult.changes.map((c) => c.message));

    console.log('7. Personal /me/ view for Kabir');
    const me = await req('GET', `/me/${kabir.token}`);
    console.log('   Kabir owes:', me.amountOwed, '| activities:', me.activities.map((a) => a.name));

    console.log('8. Fairness check');
    const fairness = await req('GET', `/trips/${tripId}/fairness?admin=${adminToken}`);
    console.log('   average:', fairness.groupAverage, '| flagged:', fairness.flagged.map((f) => f.name));

    console.log('9. Settle (debt simplifier)');
    const settle = await req('POST', `/trips/${tripId}/settle?admin=${adminToken}`);
    console.log('   transactions:', settle.transactions);

    console.log('10. Bad admin token is rejected');
    const res = await fetch(`${BASE}/trips/${tripId}?admin=wrong`);
    if (res.status !== 403) throw new Error('Expected 403 for wrong admin token, got ' + res.status);
    console.log('   -> 403 as expected');

    console.log('\n✅ All checks passed.');
    process.exitCode = 0;
  } catch (err) {
    console.error('❌ Test failed:', err.message);
    process.exitCode = 1;
  } finally {
    server.close();
  }
});
