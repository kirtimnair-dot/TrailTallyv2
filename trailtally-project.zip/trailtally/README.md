# TrailTally

Full project: `backend/` (your Express API, unchanged) + `frontend/` (Vite + React, wired to it).

## Run it (two terminals)

**Terminal 1 — backend**
```bash
cd backend
npm install
npm start
```
Runs on `http://localhost:4000`. Verify with `curl http://localhost:4000/health`.

**Terminal 2 — frontend**
```bash
cd frontend
npm install
npm run dev
```
Runs on `http://localhost:5173`.

## Using it

1. Open `http://localhost:5173/` — create a trip. This calls `POST /trips` and redirects you
   to `/organizer/:tripId/:adminToken` — **bookmark or save this URL**, it's your only way back
   into the organizer dashboard (there's no login).
2. Add participants — each gets a personal token. Click **WhatsApp** or **QR** next to their
   name to get their `/me/:token` link.
3. Add bookings — split cost across selected participants, pick who paid.
4. Remove a participant or the app calls the diff-returning endpoints, and a dialog shows
   exactly whose balance moved (`store.js`'s `computeDiff` — the actual USP).
5. Anyone with a `/me/:token` link sees only their own itinerary and balance — no login, no
   backend admin access.
6. A ⚠️ badge appears next to any participant the fairness z-score check flags as a cost
   outlier (`GET /trips/:id/fairness`).

## Notes

- The frontend's `src/api/client.js` points at `http://localhost:4000` — change the `baseURL`
  there if you deploy the backend elsewhere.
- CORS is already open on the backend (`cors()` with defaults), so no proxy config needed.
- The in-memory store resets whenever the backend restarts — expected for a demo/hackathon build.
- `backend/run_test.js` is a good sanity check any time you touch backend logic:
  `cd backend && node run_test.js`.
